const mongoose = require('mongoose');

const dbName = 'apinode';
// Si MongoDB tourne sur un autre port, modifiez ici
const uri = `mongodb://127.0.0.1:27017/${dbName}`;

const clientOptions = {
    useNewUrlParser: true,
    useUnifiedTopology: true,
};

exports.initClientDbConnection = async () => {
    try {
        await mongoose.connect(uri, clientOptions);
        console.log('Connected to MongoDB');
    } catch (error) {
        console.error('Error connecting to MongoDB:', error);
        // Vous pouvez ajouter une tentative de reconnexion ou autres gestion d'erreur ici
        throw error;
    }
}