const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const bcrypt = require('bcrypt');

// Schéma User avec validation d'unicité de l'email et longueur minimale du mot de passe
const UserSchema = new Schema({
    userName: {
        type: String,
        trim: true,
        required: [true, 'un nom est requis'],
    },
    email: {
        type: String,
        trim: true,
        required: [true, 'un email est requis'],
        unique: true,
        lowercase: true,
        validate: {
            validator: function(v) {
                // Vérifie si l'email est au bon format
                return /^\S+@\S+\.\S+$/.test(v);
            },
            message: props => `${props.value} n'est pas un email valide`
        }
    },
    password: {
        type: String,
        trim: true,
        required: [true, 'un mot de passe est requis'],
        minlength: [6, 'Le mot de passe doit contenir au moins 6 caractères']
    }
}, {
    timestamps: true
});

// Pré-sauvegarde pour hasher le mot de passe
UserSchema.pre('save', async function(next) {
    if (!this.isModified('password')) {
        return next();
    }
    try {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
        next();
    } catch (err) {
        next(err);
    }
});

/* --- Autres schemas --- */

const catwaySchema = new Schema({
    catwayNumber: {
        type: String,
        trim: true,
        required: [true, 'un numéro est requis'],
        unique: true,
        validate: {
            validator: function(v) {
                // Vérifie que la chaîne ne contient que des chiffres
                return /^\d+$/.test(v);
            },
            message: props => `${props.value} doit contenir uniquement des chiffres`
        }
    },
    catwayType: {
        type: String,
        trim: true,
        required: [true, 'un type est requis'],
        lowercase: true,
        enum: ['long', 'short'], // valeurs autorisées
    },
    catwayState: {
        type: String,
        trim: true,
        required: [true, 'un état de la passerelle est requis'],
        enum: [
            'bon état',    // exemple d'états possibles, à adapter selon vos besoins
            'En cours de réparation. Ne peut être réservée actuellement',
            'Plusieurs grandes tâches de peinture bleue sur le ponton',
            "grosse tâche d'huile et trou en fin de ponton",
            "2 planches bougent lorsqu'on marche dessus"
        ],
    }
}, {
    timestamps: true
});

catwaySchema.pre('save', async function(next) {
    if (!this.isModified('password')) {
        return next();
    }
    try {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
        next();
    } catch (err) {
        next(err);
    }
});

const reservationSchema = new Schema({
    catwayNumber: {
        type: String,
        trim: true,
        required: [true, 'un numéro est requis'],
        validate: {
            validator: function(v) {
                // Vérifie que la chaîne ne contient que des chiffres
                return /^\d+$/.test(v);
            },
            message: props => `${props.value} doit contenir uniquement des chiffres`
        }
    },
    clientName: {
        type: String,
        trim: true,
        required: [true, 'un nom est requis'],
    },
    boatName: {
        type: String,
        trim: true,
        required: [true, 'un nom de bateau est requis']
    },
    startDate: {
        type: Date,
        required: [true, 'une date de début est requise'],
        validate: {
            validator: function(v) {
                // Vérifie que la valeur est une date valide
                return v instanceof Date && !isNaN(v.getTime());
            },
            message: props => `${props.value} n'est pas une date valide`
        }
    },
    endDate: {
        type: Date,
        required: [true, 'une date de fin est requise'],
        validate: {
            validator: function(v) {
                // Vérifie que la valeur est une date valide
                return v instanceof Date && !isNaN(v.getTime());
            },
            message: props => `${props.value} n'est pas une date valide`
        }
    }
}, {
    timestamps: true
});

reservationSchema.pre('save', async function(next) {
    if (!this.isModified('password')) {
        return next();
    }
    try {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
        next();
    } catch (err) {
        next(err);
    }
});

// Export des modèles
const User = mongoose.model('User', UserSchema);
const Catways = mongoose.model('Catways', catwaySchema);
const Reservation = mongoose.model('Reservation', reservationSchema);

module.exports = {
    User,
    Catways,
    Reservation
};